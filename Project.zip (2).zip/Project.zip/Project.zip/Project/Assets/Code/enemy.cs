using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy : MonoBehaviour
{
    void Start()
    {
        
    }


    void Update()
    {
        
    }
}

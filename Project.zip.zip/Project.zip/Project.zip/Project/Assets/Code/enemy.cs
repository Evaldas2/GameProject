using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy : MonoBehaviour
{
    public GameObject Enemy;
    public bool enemyRight = false;
    public bool enemyLeft = false;
    public Animator enemyAnimator;
    public float enemySpeed = 2.0f;
  
    void Start()
    {
        enemySpeed = 1.0f;
        InvokeRepeating("Accelerate", 2, 5);
    }


    void Update()
    {
        enemyMove();
    }

    private void enemyMove()
    {
        enemyAnimator = GetComponent<Animator>();

        if(transform.position.y <= -5.2)
        {
            enemyAnimator.SetBool("enemyLeft", true);
            enemyAnimator.SetBool("enemyRight", false);
            enemyLeft = true;
            enemyRight = false;
            transform.Translate(Vector3.left * enemySpeed * Time.deltaTime);
        }

    }
    private void Accelerate()
    {
        enemySpeed = enemySpeed + 1;
    }
}

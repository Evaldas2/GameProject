using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class enemyV2 : MonoBehaviour
{
    public GameObject Enemy;
    public Animator EnemyAnimator;
    public bool enemyRight = false;
    public bool enemyLeft = false;
    public float Speed = 2f;
    public float Speed2 = -2f;

    public int LivesLeft = 2;

    void Start()
    {
        Speed = 0.5f;
        Speed2 = -0.5f;
    }


    void Update()
    {
        enemyMove();
    }

    private void enemyMove()
    {
        EnemyAnimator = GetComponent<Animator>();
        EnemyAnimator.SetBool("enemyLeft", true);
        EnemyAnimator.SetBool("enemyRight", false);
        enemyLeft = true;
        enemyRight = false;
        transform.Translate(Vector3.right * Speed * Time.deltaTime);
    }

    private void enemyMove2()
    {
        EnemyAnimator = GetComponent<Animator>();
        EnemyAnimator.SetBool("enemyLeft", false);
        EnemyAnimator.SetBool("enemyRight", true);
        enemyLeft = false;
        enemyRight = true;
        transform.Translate(Vector3.left * Speed * Time.deltaTime);
    }

    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "LeftTile" || collision.gameObject.name == "LeftEdge")
        {
            enemyMove();
        }

        if (collision.gameObject.name == "RightTile" || collision.gameObject.name == "RightEdge")
        {
            enemyMove2();
        }

        if (collision.gameObject.name == "05(Clone)")
        {
            if (LivesLeft > 0)
            {
                LivesLeft -= 1;
                Destroy(collision.gameObject);
            }

            if (LivesLeft == 0)
            {
                Destroy(gameObject);
            }
        }
    }

}

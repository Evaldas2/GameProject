using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossControl : MonoBehaviour
{
    public GameObject firePrefab;
    public int LivesLeft = 20;

    public float fireSpeed = 5.0f;
    public float fireSpeed2 = -5.0f;
    public Transform fireLocation;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        Rigidbody2D fireInstance;
        if (Input.GetButtonDown("Fire1"))
        {
            GameObject orb = Instantiate(firePrefab, fireLocation.position, fireLocation.rotation);
            Rigidbody2D rb = orb.GetComponent<Rigidbody2D>();
            rb.AddForce(fireLocation.right * fireSpeed2, ForceMode2D.Impulse);
        }
    }

    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "AstroWalk")
        {
            LivesLeft -= 1;
            if (LivesLeft == 0)
            {
                Time.timeScale = 0;
                Destroy(gameObject);
            }
        }

        if (collision.gameObject.name == "05(Clone)")
        {
            Destroy(collision.gameObject);
            LivesLeft -= 1;
            if (LivesLeft == 0)
            {
                Destroy(gameObject);
            }
        }
    }

    public void OnGUI()
    {
        GUI.Box(new Rect(585, 10, 100, 50), "The Boss Boss" + "\n Lives: " + LivesLeft);
    }
}
